# AttendanceIQ

Face + Gesture based attendance system built with Python, OpenCV, MediaPipe, and Tkinter.

## Project Structure

```
AttendanceIQ/
├── main.py                          ← Entry point, full Tkinter UI
├── requirements.txt
├── data/                            ← Auto-created at runtime
│   ├── students.json
│   ├── records.json
│   └── faces.pkl
└── modules/
    ├── __init__.py
    ├── face_recognition_module.py   ← Face detection + embedding + matching
    ├── gesture_module.py            ← MediaPipe hand gesture classification
    └── attendance_module.py         ← Student CRUD + attendance records + CSV export
```

## How to Run

```bash
pip install -r requirements.txt
python main.py
```

## Module Responsibilities

| Module | What it does |
|--------|-------------|
| `face_recognition_module.py` | Haar cascade detection, 64×64 histogram-equalised embedding, cosine-similarity matching, pickle persistence |
| `gesture_module.py` | MediaPipe Hands wrapper, thumbs-up / thumbs-down / none classification |
| `attendance_module.py` | Add/remove students, mark present/absent, mark remaining absent, export CSV, stats |
| `main.py` | Tkinter UI — wires all three modules together, camera loop, face capture flow |

## Key Concepts (for interviews)

- **Why cosine similarity?** It measures the angle between vectors, making it scale-invariant (brightness changes don't affect the score as much as Euclidean distance).
- **Why histogram equalisation?** Normalises lighting differences so the same face looks similar under different room lighting.
- **Why threading?** Camera loop runs on a background thread so the Tkinter UI (main thread) stays responsive.
- **face_db format?** `{ student_id: [embedding_1, ..., embedding_10] }` — 10 embeddings per student for robustness.
- **Where is data stored?** JSON files for students/records (human-readable), pickle for face embeddings (binary numpy arrays).
